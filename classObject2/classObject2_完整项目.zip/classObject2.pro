QT       += core gui network xml

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    deepseekapi.cpp \
    docxhelper.cpp \
    workerthread.cpp

HEADERS += \
    mainwindow.h \
    deepseekapi.h \
    docxhelper.h \
    workerthread.h


