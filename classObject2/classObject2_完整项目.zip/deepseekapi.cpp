#include "deepseekapi.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QEventLoop>
#include <QTimer>

DeepSeekApi::DeepSeekApi(QObject *parent)
    : QObject(parent)
    , m_manager(new QNetworkAccessManager(this))
    , m_endpoint("https://api.deepseek.com")
    , m_apiKey("")
    , m_temperature(0.7)
{
}

void DeepSeekApi::setEndpoint(const QString &url)
{
    m_endpoint = url;
    // 去掉末尾斜杠，免得拼 URL 时出双斜杠
    while (m_endpoint.endsWith('/'))
        m_endpoint.chop(1);
}

void DeepSeekApi::setApiKey(const QString &key)
{
    m_apiKey = key;
}

void DeepSeekApi::setTemperature(double temp)
{
    m_temperature = qBound(0.0, temp, 1.0);
}

/*
 * ==============================================
 * 同步调用 DeepSeek API
 * 思路：用 QEventLoop 等待网络回复
 * 加个 60s 超时，避免网络卡死
 * ==============================================
 */
QString DeepSeekApi::generateCommentSync(const QString &score,
                                          const QString &prompt,
                                          QString &errorMsg)
{
    // 参数校验
    if (m_endpoint.isEmpty() || m_apiKey.isEmpty()) {
        errorMsg = "API 配置不完整，请检查 URL 和 API Key";
        return QString();
    }

    // 构建请求 body
    QJsonObject body;
    body["model"] = "deepseek-chat";

    QJsonArray messages;

    // system 角色：告诉 AI 它要扮演什么
    QJsonObject sysMsg;
    sysMsg["role"] = "system";
    sysMsg["content"] = "你是一名高校专业课教师。请根据学生实验成绩和实验要求，"
                        "生成一段专业、具体、有针对性的教师评语。"
                        "评语要求：语气客观公正，先肯定优点再指出不足，最后给出改进建议。"
                        "字数控制在50-120字之间。";
    messages.append(sysMsg);

    // user 角色：传入实际数据
    QJsonObject userMsg;
    userMsg["role"] = "user";
    userMsg["content"] = QString("学生实验成绩：%1分\n实验要求：%2\n请生成教师评语。")
                             .arg(score, prompt);
    messages.append(userMsg);

    body["messages"] = messages;
    body["temperature"] = m_temperature;
    // 让回复稳定一点，少发散
    body["top_p"] = 0.9;

    QJsonDocument doc(body);
    QByteArray postData = doc.toJson(QJsonDocument::Compact);

    // 构建网络请求
    QNetworkRequest request(QUrl(m_endpoint + "/chat/completions"));
    request.setRawHeader("Content-Type", "application/json");
    request.setRawHeader("Authorization",
                         QString("Bearer %1").arg(m_apiKey).toUtf8());

    // 发 POST
    QNetworkReply *reply = m_manager->post(request, postData);

    // 用事件循环等待回复
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);

    // 超时处理：取消请求
    QObject::connect(&timer, &QTimer::timeout, [&]() {
        reply->abort();
        timer.stop();
    });

    // 收到回复就退出事件循环
    QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);

    timer.start(60000); // 60 秒超时
    loop.exec();

    // 处理结果
    QString result;
    if (timer.isActive()) {
        timer.stop(); // 正常完成，关闭定时器

        if (reply->error() != QNetworkReply::NoError) {
            errorMsg = QString("网络请求失败：%1").arg(reply->errorString());
        } else {
            QByteArray responseData = reply->readAll();
            QJsonDocument respDoc = QJsonDocument::fromJson(responseData);

            if (respDoc.isNull() || !respDoc.isObject()) {
                errorMsg = "API 返回数据格式异常，不是有效的 JSON";
            } else {
                QJsonObject respObj = respDoc.object();

                // 检查是否有 error 字段（API 返回的错误）
                if (respObj.contains("error")) {
                    QJsonObject errObj = respObj["error"].toObject();
                    errorMsg = QString("API 返回错误：%1")
                                   .arg(errObj["message"].toString());
                } else {
                    // 正常解析 choices[0].message.content
                    QJsonArray choices = respObj["choices"].toArray();
                    if (choices.isEmpty()) {
                        errorMsg = "API 返回的 choices 数组为空";
                    } else {
                        QJsonObject choice = choices[0].toObject();
                        QJsonObject message = choice["message"].toObject();
                        result = message["content"].toString().trimmed();
                        if (result.isEmpty()) {
                            errorMsg = "AI 生成的评语为空";
                        }
                    }
                }
            }
        }
    } else {
        // 定时器超时了
        errorMsg = "请求超时（60秒），请检查网络或 API 地址是否正确";
    }

    reply->deleteLater();
    return result;
}
