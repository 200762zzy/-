#include "docxhelper.h"

#include <QProcess>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QDomDocument>
#include <QDomNodeList>
#include <QDomElement>
#include <QDomText>
#include <QRegularExpression>
#include <QTextStream>
#include <QUuid>

/*
 * ==============================================
 * 通过 PowerShell 解压 docx 文件
 * Expand-Archive 是 PS 5.0+ 内置命令
 * ==============================================
 */
bool DocxHelper::unzipDocx(const QString &docxPath,
                            const QString &destDir,
                            QString &errorMsg)
{
    QProcess proc;
    // 先确保目标目录存在
    QDir().mkpath(destDir);

    // 构造 PowerShell 命令：Expand-Archive 解压
    QString cmd = QString(
        "Expand-Archive -Path '%1' -DestinationPath '%2' -Force"
    ).arg(QDir::toNativeSeparators(docxPath),
          QDir::toNativeSeparators(destDir));

    proc.start("powershell", QStringList() << "-NoProfile" << "-Command" << cmd);
    proc.waitForFinished(30000);

    if (proc.exitCode() != 0) {
        errorMsg = QString("解压失败：%1").arg(QString::fromUtf8(proc.readAllStandardError()).trimmed());
        return false;
    }
    return true;
}

/*
 * ==============================================
 * 通过 PowerShell 重新打包 docx
 * 注意：Compress-Archive 默认会把文件夹本身也打包进去
 * 所以用 * 通配符来压缩内部所有内容
 * ==============================================
 */
bool DocxHelper::zipDocx(const QString &srcDir,
                          const QString &docxPath,
                          QString &errorMsg)
{
    QProcess proc;

    // 先删除旧的 docx（Compress-Archive -Force 在文件存在时可能报错）
    if (QFile::exists(docxPath)) {
        QFile::remove(docxPath);
    }

    // 压缩目录下所有内容（不包括目录本身）
    QString srcPath = QDir::toNativeSeparators(srcDir) + "\\*";
    QString dstPath = QDir::toNativeSeparators(docxPath);

    QString cmd = QString(
        "Compress-Archive -Path '%1' -DestinationPath '%2' -Force"
    ).arg(srcPath, dstPath);

    proc.start("powershell", QStringList() << "-NoProfile" << "-Command" << cmd);
    proc.waitForFinished(60000);

    if (proc.exitCode() != 0) {
        errorMsg = QString("压缩失败：%1").arg(QString::fromUtf8(proc.readAllStandardError()).trimmed());
        return false;
    }
    return true;
}

/*
 * ==============================================
 * 读取 word/document.xml 全部内容
 * ==============================================
 */
QString DocxHelper::readDocumentXml(const QString &docxDir, QString &errorMsg)
{
    QString xmlPath = docxDir + "/word/document.xml";
    QFile file(xmlPath);
    if (!file.open(QIODevice::ReadOnly)) {
        errorMsg = QString("无法读取 document.xml：%1").arg(file.errorString());
        return QString();
    }

    QString content = QString::fromUtf8(file.readAll());
    file.close();
    return content;
}

/*
 * ==============================================
 * 写回 word/document.xml
 * ==============================================
 */
bool DocxHelper::writeDocumentXml(const QString &docxDir,
                                   const QString &xmlContent,
                                   QString &errorMsg)
{
    QString xmlPath = docxDir + "/word/document.xml";
    QFile file(xmlPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        errorMsg = QString("无法写入 document.xml：%1").arg(file.errorString());
        return false;
    }

    QTextStream stream(&file);
    stream.setCodec("UTF-8");
    stream << xmlContent;
    file.close();
    return true;
}

/*
 * ==============================================
 * 从 docx 中提取成绩分数
 *
 * 逻辑：
 *   1. 解压 docx 到临时目录
 *   2. 读取 word/document.xml
 *   3. 遍历所有 w:t 元素（文本节点）
 *   4. 找包含 "成绩""分数""得分" 的文本
 *   5. 用正则抠出数字
 *   6. 清理临时目录
 * ==============================================
 */
QString DocxHelper::extractScore(const QString &docxPath, QString &errorMsg)
{
    // 搞个唯一的临时目录名，避免多线程打架
    QString tempDir = QDir::tempPath() + "/docx_" +
                      QUuid::createUuid().toString(QUuid::WithoutBraces).left(8);

    // 解压
    if (!unzipDocx(docxPath, tempDir, errorMsg)) {
        QDir(tempDir).removeRecursively();
        return QString();
    }

    // 读取 XML
    QString xmlContent = readDocumentXml(tempDir, errorMsg);
    if (xmlContent.isEmpty()) {
        QDir(tempDir).removeRecursively();
        return QString();
    }

    // ==============================================
    // 解析 XML 提取分数
    // 先用 QDomDocument 把 XML 加载成 DOM 树
    // 然后用 elementsByTagNameNS 找命名空间 w 下的 t 元素
    // ==============================================
    QDomDocument doc;
    if (!doc.setContent(xmlContent)) {
        errorMsg = "document.xml 格式解析失败";
        QDir(tempDir).removeRecursively();
        return QString();
    }

    // docx 的标准命名空间
    QString ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

    // 获取所有 w:t 元素
    QDomNodeList textNodes = doc.elementsByTagNameNS(ns, "t");

    // 逐个检查文本内容
    QRegularExpression scoreRe("(\\d+[\\.]?\\d*)"); // 匹配数字（含小数）

    for (int i = 0; i < textNodes.size(); i++) {
        QDomElement elem = textNodes.item(i).toElement();
        QString text = elem.text().trimmed();

        // 只看包含成绩相关关键词的文本
        if (text.contains("成绩") || text.contains("分数") ||
            text.contains("得分") || text.contains("评分")) {

            QRegularExpressionMatch match = scoreRe.match(text);
            if (match.hasMatch()) {
                QString score = match.captured(1);
                QDir(tempDir).removeRecursively();
                return score; // 返回第一个匹配的分数
            }
        }
    }

    // 没找到分数
    QDir(tempDir).removeRecursively();
    errorMsg = "未在文档中找到成绩分数";
    return QString();
}

/*
 * ==============================================
 * 将 AI 评语写入 docx
 *
 * 逻辑：
 *   1. 解压 docx
 *   2. 读取 word/document.xml
 *   3. 找到包含 "教师评语" 或 "评语" 的段落（w:p）
 *   4. 清空该段落的所有文本，写入新评语
 *   5. 如果找不到，在文档末尾追加新段落
 *   6. 保存 XML，重新打包
 *   7. 清理临时目录
 * ==============================================
 */
bool DocxHelper::writeComment(const QString &docxPath,
                               const QString &comment,
                               QString &errorMsg)
{
    // 参数校验
    if (comment.isEmpty()) {
        errorMsg = "评语内容为空，跳过写入";
        return false;
    }

    // 临时目录
    QString tempDir = QDir::tempPath() + "/docx_" +
                      QUuid::createUuid().toString(QUuid::WithoutBraces).left(8);

    // 解压
    if (!unzipDocx(docxPath, tempDir, errorMsg)) {
        QDir(tempDir).removeRecursively();
        return false;
    }

    // 读取 XML
    QString xmlContent = readDocumentXml(tempDir, errorMsg);
    if (xmlContent.isEmpty()) {
        QDir(tempDir).removeRecursively();
        return false;
    }

    // ==============================================
    // 用 QDomDocument 解析和修改 XML
    // ==============================================
    QDomDocument doc;
    if (!doc.setContent(xmlContent)) {
        errorMsg = "document.xml 格式解析失败";
        QDir(tempDir).removeRecursively();
        return false;
    }

    QString ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

    // 找到所有 w:t 文本节点
    QDomNodeList textNodes = doc.elementsByTagNameNS(ns, "t");

    bool found = false;
    QDomElement targetParagraph; // 要替换的段落

    // 遍历找 "评语" 关键字
    for (int i = 0; i < textNodes.size(); i++) {
        QDomElement tElem = textNodes.item(i).toElement();
        if (tElem.text().contains("评语")) {
            // 找到评语标签，往上找父级 w:p 段落
            QDomNode parent = tElem.parentNode(); // w:r
            while (!parent.isNull() && parent.isElement()) {
                QDomElement pe = parent.toElement();
                if (pe.localName() == "p" &&
                    pe.namespaceURI() == ns) {
                    targetParagraph = pe;
                    found = true;
                    break;
                }
                parent = parent.parentNode();
            }
            if (found) break;
        }
    }

    if (found) {
        // ==============================================
        // 找到评语段落了
        // 删掉里面的所有 w:r（文本运行），替换为新的评语
        // 保留段落属性（w:pPr）不删，保持格式
        // ==============================================
        QDomNodeList runs = targetParagraph.elementsByTagNameNS(ns, "r");

        // 从后往前删，避免索引错乱
        QList<QDomElement> runList;
        for (int i = 0; i < runs.size(); i++) {
            runList.append(runs.item(i).toElement());
        }
        for (int i = runList.size() - 1; i >= 0; i--) {
            targetParagraph.removeChild(runList[i]);
        }

        // 创建新的 w:r → w:t
        QDomElement newRun = doc.createElementNS(ns, "r");
        QDomElement newText = doc.createElementNS(ns, "t");
        // 设置 xml:space="preserve" 保持空格和换行
        newText.setAttribute("xml:space", "preserve");

        QDomText textNode = doc.createTextNode("教师评语：" + comment);
        newText.appendChild(textNode);
        newRun.appendChild(newText);
        targetParagraph.appendChild(newRun);
    } else {
        // ==============================================
        // 没找到评语段落，在文档末尾追加
        // 找到 <w:body>，在 <w:sectPr> 之前插入新段落
        // 如果没有 sectPr，直接追加到 body 末尾
        // ==============================================
    QDomElement docElem = doc.documentElement();
    // firstChildElement 在 Qt 5.14 只支持标签名参数（带前缀）
    // docx 的标准前缀是 w:，所以这里用 "w:body"
    QDomElement body = docElem.firstChildElement("w:body");

    if (body.isNull()) {
        errorMsg = "文档结构异常：未找到 body 元素";
        QDir(tempDir).removeRecursively();
        return false;
    }

    // 创建新段落
    QDomElement newP = doc.createElementNS(ns, "p");
    QDomElement newRun = doc.createElementNS(ns, "r");
    QDomElement newText = doc.createElementNS(ns, "t");
    newText.setAttribute("xml:space", "preserve");

    QDomText textNode = doc.createTextNode("教师评语：" + comment);
    newText.appendChild(textNode);
    newRun.appendChild(newText);
    newP.appendChild(newRun);

    // 在 sectPr 之前插入
    QDomElement sectPr = body.firstChildElement("w:sectPr");
    if (!sectPr.isNull()) {
        body.insertBefore(newP, sectPr);
    } else {
        body.appendChild(newP);
    }
    }

    // ==============================================
    // 把修改后的 DOM 树序列化成字符串
    // 注意：要保留原 XML 声明，不缩进
    // ==============================================
    QString newXmlContent;
    QTextStream ts(&newXmlContent);
    doc.save(ts, 0); // 0 = 不缩进，保持原有格式
    // 确保 XML 声明存在
    if (!newXmlContent.startsWith("<?xml")) {
        newXmlContent = QString("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n") + newXmlContent;
    }

    // 写回文件
    if (!writeDocumentXml(tempDir, newXmlContent, errorMsg)) {
        QDir(tempDir).removeRecursively();
        return false;
    }

    // 重新打包为 docx
    if (!zipDocx(tempDir, docxPath, errorMsg)) {
        QDir(tempDir).removeRecursively();
        return false;
    }

    // 清理临时目录
    QDir(tempDir).removeRecursively();

    return true;
}
